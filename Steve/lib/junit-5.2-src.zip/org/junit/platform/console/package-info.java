/**
 * Support for launching the JUnit Platform from the console.
 */

package org.junit.platform.console;
