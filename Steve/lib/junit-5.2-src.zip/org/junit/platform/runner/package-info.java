/**
 * {@code Runner} and annotations for configuring and executing tests on the
 * JUnit Platform in a JUnit 4 environment.
 */

package org.junit.platform.runner;
