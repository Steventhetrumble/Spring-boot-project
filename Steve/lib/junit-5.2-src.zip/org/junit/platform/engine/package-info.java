/**
 * Public API for test engines.
 */

package org.junit.platform.engine;
