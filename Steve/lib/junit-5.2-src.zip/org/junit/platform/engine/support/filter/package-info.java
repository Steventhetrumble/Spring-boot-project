/**
 * {@link org.junit.platform.engine.Filter}-related support classes intended to be
 * used by test engine implementations.
 */

package org.junit.platform.engine.support.filter;
