/**
 * {@link org.junit.platform.engine.TestDescriptor}-related support classes
 * intended to be used by test engine implementations and clients of
 * the launcher.
 */

package org.junit.platform.engine.support.descriptor;
