/**
 * Maven Surefire provider for the JUnit Platform.
 */

package org.junit.platform.surefire.provider;
