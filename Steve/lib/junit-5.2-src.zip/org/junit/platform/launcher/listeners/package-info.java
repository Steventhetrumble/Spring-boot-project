/**
 * Common {@link org.junit.platform.launcher.TestExecutionListener
 * TestExecutionListener} implementations and related support classes for
 * the {@link org.junit.platform.launcher.Launcher Launcher}.
 */

package org.junit.platform.launcher.listeners;
