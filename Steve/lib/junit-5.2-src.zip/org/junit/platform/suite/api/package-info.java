/**
 * Annotations for configuring a <em>test suite</em> on the JUnit Platform.
 */

package org.junit.platform.suite.api;
