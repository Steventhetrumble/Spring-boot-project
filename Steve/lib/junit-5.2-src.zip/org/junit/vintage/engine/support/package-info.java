/**
 * Internal support classes for test discovery and execution within the JUnit
 * Vintage test engine.
 */

package org.junit.vintage.engine.support;
