/**
 * Test descriptors used within the JUnit Vintage test engine.
 */

package org.junit.vintage.engine.descriptor;
