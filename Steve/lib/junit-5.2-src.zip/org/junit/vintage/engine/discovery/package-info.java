/**
 * Internal classes for test discovery within the JUnit Vintage test engine.
 */

package org.junit.vintage.engine.discovery;
