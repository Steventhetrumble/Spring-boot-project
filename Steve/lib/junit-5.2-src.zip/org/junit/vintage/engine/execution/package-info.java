/**
 * Internal classes for test execution within the JUnit Vintage test engine.
 */

package org.junit.vintage.engine.execution;
